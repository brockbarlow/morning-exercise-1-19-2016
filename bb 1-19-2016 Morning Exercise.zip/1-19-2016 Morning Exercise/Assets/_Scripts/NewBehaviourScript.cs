﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour {

    void Awake()
    {
        Debug.Log("Awake");
    }

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
